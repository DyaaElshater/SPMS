<?php
include("header.php");
?>

<html>
<style>
#map-canvas{
    width: 850px;
    height: 300px;
}
</style>
<script src= "//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js" ></script>
<script src= "//maps.googleapis.com/maps/api/js?key=AIzaSyDqvp9BxXXlzzGk0NIfwUFpr91jXVxVBA4" 
type="text/javascript" ></script>

<div class="col-md-12">
<div class="card">
<div class="header">
<h4 class="title">Add New Camera</h4>
</div>


<div class="container-fluid">
<div class="row">
<div class="content">


<form action="" method='post'>
<div class="row">

<div class="col-md-6">
<div class="form-group">
    <label>Position Description</label>
    <input name ="desc" type="text" class="form-control border-input" placeholder="Description" required>

</div>
</div>

<div class="col-md-4">
<div class="form-group">
    <label>Capacity</label>
    <input name ="cap" type="number" class="form-control border-input" placeholder="vehicles capacity" required>

</div>
</div>
<input type="hidden" name="lat" id="lat" value="">
<input type="hidden" name="lng" id="lng" value="">
</div>

<div id="map-canvas">
</div>

<div class="text-center">
<button type="submit" name="add" class="btn btn-info btn-fill btn-wd">Add Camera</button>
</div>
</form>

</div>



</div>
</div>


</div>
</div>

<?php

if(isset($_POST['add'])){
    $cap = $_POST['cap'];
    $desc = $_POST['desc'];
    $lng = $_POST['lng'];
    $lat = $_POST['lat'];


	$qob = "INSERT INTO `lot`(`location`, `capacity`,`lng`,`lat`)
    VALUES ('$desc', '$cap', '$lng', '$lat')";
    
	if(mysqli_query($GLOBALS['connection'],$qob)){
    $last_id = $GLOBALS['connection']->insert_id; 
    // insert intial status for added cam
    $qob = "INSERT INTO `status`(`lotId`, `filledSlot`)
    VALUES ('$last_id', '0')";
    mysqli_query($GLOBALS['connection'],$qob);
	echo '<div class="alert alert-success"> <b class="l-name"></b>  Added Successfully     </div>';	    
    }
}
?>

               
     


     
  <?php
  include("footer.php");
  ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>




<script>
var map = new google.maps.Map(document.getElementById("map-canvas"),{
center:{
lat: 24.0889,
lng: 32.8998
},
zoom: 16
});

var marker = new google.maps.Marker({
position:{
lat: 24.0889,
lng: 32.8998  
},
map: map,
draggable: true
});

google.maps.event.addListener(marker,'dragend',function(){
    var lat = marker.getPosition().lat();
    var lng = marker.getPosition().lng();
    $('#lat').val(lat);
    $('#lng').val(lng);
    console.log(lat);
    console.log(lng);
    
    });
</script>







</body>
</html>