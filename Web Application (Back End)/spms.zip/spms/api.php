<?php
require("config.php");

if(isset($_GET['get']) && $_GET['get'] == "android"){
	
$q70="SELECT lot.id,lot.location,lot.capacity,lot.lng,lot.lat,
        status.filledSlot
        FROM lot 
        INNER JOIN status
        ON lot.id = status.lotId
        WHERE status.currentTime = 
        (SELECT max(status.currentTime) FROM status  WHERE status.lotId = lot.id)
        ";
$response = array();

$r_q70=mysqli_query($GLOBALS['connection'],$q70);
while ($d=mysqli_fetch_assoc($r_q70))

{
      $d['empty'] = $d["capacity"] - $d["filledSlot"];
      if( $d['empty'] <0 ) $d['empty'] = "No available slots ---- reading Error" ;
      $response[] = $d; 
}
echo json_encode(array('lot'=>$response));
}



//http://192.168.137.78/spms/api.php?get=python&filled=?&lot=?
if(isset($_GET['get']) && $_GET['get'] == "python"){

$filled = $_GET[filled];
$lot = $_GET[lot];
      
$q70="UPDATE status SET filledSlot = '{$filled}' WHERE lotId = '$lot'";
$r_q70=mysqli_query($GLOBALS['connection'],$q70);
      
}
?>