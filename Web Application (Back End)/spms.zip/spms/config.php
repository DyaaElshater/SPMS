<?php
    $GLOBALS['connection'] = new mysqli("localhost","root","","spms");
    if ($GLOBALS['connection'] -> connect_error){
    	die('not connected');
    }else{
    	$GLOBALS['connection'] -> query("SET NAMES 'utf8'");
    	$GLOBALS['connection'] -> set_charset('utf8');
    	$GLOBALS['connection'] -> query("SET COLLATION_CONNECTION = utf8_general_ci");
    }
?>