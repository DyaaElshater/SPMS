
<?php
include("header.php");

if(isset($_GET['id']))
{
    $id=$_GET['id']; 
    $q159="DELETE  FROM `lot` WHERE `id`='{$id}'";
    $r_q159=mysqli_query($GLOBALS['connection'],$q159);
    header("location: index.php");
}

?>