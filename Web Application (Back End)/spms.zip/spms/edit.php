<?php
include("header.php");

function is_exist($id){
$q70 = "SELECT `id` from `lot` WHERE `id` = $id";
$r_q70=mysqli_query($GLOBALS['connection'],$q70);
$num = mysqli_num_rows($r_q70);
if($num) return true;
else return false;
}



$id = $_GET['id'];
if(is_numeric($id)  && is_exist($id)){
    // user entered right id then lets get the old data
    $q70 = "SELECT `location`,`capacity` FROM `lot` WHERE `id` = $id";
    $r_q70=mysqli_query($GLOBALS['connection'],$q70);
    $d=mysqli_fetch_assoc($r_q70);

}
else{
    header("location: index.php");
}
?>





<html>
<div class="col-md-12">
<div class="card">
<div class="header">
<h4 class="title">Edit Camera</h4>
</div>


<div class="container-fluid">
<div class="row">
<div class="content">


<form action="" method='post'>
<div class="row">

<div class="col-md-6">
<div class="form-group">
    <label>Position Description</label>
    <input name ="desc" type="text" class="form-control border-input" placeholder="Description" value ='<?php echo $d["location"];?>' required >

</div>
</div>

<div class="col-md-4">
<div class="form-group">
    <label>Capacity</label>
    <input name ="cap" type="number" class="form-control border-input" placeholder="vehicles capacity" value ='<?php echo $d["capacity"];?>' required>

</div>


<div id="map-canvas">
</div>

<div class="text-center">
<button type="submit" name="edit" class="btn btn-info btn-fill btn-wd">Edit Camera</button>
</div>
</form>

</div>



</div>
</div>


</div>
</div>

<?php

if(isset($_POST['edit'])){
    $cap = $_POST['cap'];
    $desc = $_POST['desc'];

	$qob = "UPDATE lot SET `location` = '{$desc}', `capacity` = '{$cap}' WHERE id=$id";
    if(mysqli_query($GLOBALS['connection'],$qob))
	echo '<div class="alert alert-success"> <b class="l-name"></b>  Updated Successfully </div>';	    
    
}
?>

               
     


     
  <?php
  include("footer.php");
  ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>



</body>
</html>