<?php
include("header.php");
?>


<div class="col-md-12">
<br>
<div class="card">
<div class="header">
<h4 class="title">Locations</h4>
</div>
<div class="content table-responsive table-full-width">
<table class="table table-striped">
<thead>
<th>Lot ID</th>
<th>Location</th>
<th>Total capacity</th>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
<th>Occupied Slots</th>
<th>Free Slots </th>
<th>Action </th>


</thead>
<tbody>

<?php



$q70 = "SELECT lot.id,lot.location,lot.capacity,
        status.filledSlot
        FROM lot 
        INNER JOIN status
        ON lot.id = status.lotId
        ";
$r_q70=mysqli_query($GLOBALS['connection'],$q70);
$message = "'Are you sure You wanna get this camera out? '";
while ($d=mysqli_fetch_assoc($r_q70))
{
  $empty = intval($d['capacity']) - intval($d['filledSlot']);
  echo '<tr>
  <td>'.$d['id'].'</td>';
  echo '<td>'.$d['location'].'</td>';
  echo '<td>'.$d['capacity'].'</td>';
  echo '<td>'.$d['filledSlot'].'</td>';
  echo '<td>'.$empty.'</td>';
  echo '<td  ><a href='.URL.'edit.php?id='.$d['id'].' data-toggle="tooltip" data-placement="top"  class="btn btn-primary btn-xs tooltips" title="EDIT"><i class="fa fa-edit fa-sm"></i></a>
  <a  onclick="return confirm('.$message.')" href='.URL.'delete.php?id='.$d['id'].' data-toggle="tooltip" data-placement="top" title="Delete" class="btn btn-danger btn-xs tooltips"><i class="fa fa-times"></i></a></td>';
  echo "</tr>";
}
?>

</tbody>
</table>

</div>
</div>
</div>


               
     


     
  <?php
  include("footer.php");
  ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
