<?php 
define('URL','http://localhost/spms/');

?>
