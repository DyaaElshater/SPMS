
How to install our Admin Panel ?? "SPMS"

1- install local server on your pc such as xampp or wampp
2- copy the spms folder into htdocs folder if you are using xampp or www folder if using wampp
3- import our database using phpmyqadmin, you will find spms.sql into spms folder 
4- now you can run our admin panel, just run your local server then open your browser and go to >>> http://localhost/spms
5- api.php is written for two reasons
 	1- getting the data from object detection code "go to python code and read the update function"
 	2- sending json to the mobile app 

5- for any inquiries feel free to contact me

contacts:
Waleed Hamdy Abudeif 
01095615864
https://www.linkedin.com/in/waleed-hamdy-a01052129/


